<div class="container-fluid content_full">
    <div class="row">
        <div class="col-md-2 sidebar">
            <div class="sidebar_user">
                <img src="uploads/<?= $_SESSION['photo'];?>" alt="user" class="img-responsive"/>
                <h4><?= $_SESSION['name'];?></h4>
                <p><i class="fa fa-circle"></i> online</p>
            </div>
            <div class="menu">
                <h2>MAIN NAVIGATION</h2>
                <ul>
                    <li><a href="dash.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <?php if($_SESSION['role']<=1){?>
                    <li><a href="all-user.php"><i class="fa fa-user"></i> User</a></li>
                    <?php }?>
                    
                    <li><a href="all-circuler.php"><i class="fa fa-cubes"></i> Circular</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
                </ul>
            </div>
        </div><!--sidebar end-->