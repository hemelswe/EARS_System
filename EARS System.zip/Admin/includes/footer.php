			</div><!--content part end-->
        </div><!--row end-->
</div><!--container-fluid end-->
<div class="container-fluid footer_full">
    	<div class="container footer">
        	<div class="row">
            
            </div><!--row end-->
        </div><!--container end-->
    </div><!--container-fluid end-->
    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>