<?php
    require_once("functions/function.php");
    get_part('header.php');
?>
<!-- Login start --> 
<div class="container-fluid login_main">
<h1 class="login_heading">  Sign In your Account </h1>
<div class="login_wrapper">
<?php
                if(!empty($_POST)){
                $name=$_POST['username'];
                $pass=md5($_POST['password']);
                $sel="SELECT * FROM applicants WHERE app_username='$name' AND app_password='$pass'";
                $qry=mysqli_query($con, $sel);
                $res=mysqli_fetch_array($qry);
                if($res){
                        $_SESSION['name']=$res['app_name'];
                        $_SESSION['user']=$res['app_username'];
                        header('location: all-circuler.php');
                }else{
                        echo "Username and Password incorrect!!!";	
                        }
                }
?>    
<form class="login_form_1">
    <div class="input-group form-group-lg">
      <span class="input-group-addon"><i class="fa fa-users fa-lg" aria-hidden="true"></i></span>
      <input id="email" type="text" class="form-control" name="email" placeholder="Email">
    </div><br/>
    <div class="input-group form-group-lg">
      <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password">
    </div>
<div class="login_check_0">
<label class="checkbox-inline login_check_1 "><input type="checkbox" value="">Remember</label>
</div>
</form>
<div class="login_submit_button_0">
<a href="#"><button class="btn btn-primary btn-lg">LOGIN</button></a>
</div>
<h3 class="login_or_0"> OR</h3>
<div>
<h3 class="login_or_another "> Dont have an account? <a href="registration.html"> Register </a> </h3>
</div>
</div>
</div>
<!-- Login end -->
 <?php
 get_part('footer.php');
 ?>