<?php 
    require_once("functions/function.php");
   
    get_part('header.php');
    get_part('slider.php');
    get_part('browse.php');
    get_part('search.php');
?> 
<!-- gallery start -->
<section id="card">
<div class="container ">
        <div class="text-center">
           <h2 class="text-center" >RECENT JOB OFFER</h2>
        </div>

    <div class="col-md-12">
        <div id="mdb-lightbox-ui"></div>
        <div class="mdb-lightbox">
        <div class="row"> 
            <?php
                          
                $sel="select * from job_circuler natural join job_category order by job_id desc";
                $qry=mysqli_query($con,$sel);
                while($data=mysqli_fetch_array($qry)){
		
            ?>
            <figure class="col-md-4">
            <div class=" card card-cascade view overlay hm-white-slight">
                <a href="details.php" data-size="1600x1067">                    
                <figcaption>
                    <div class="card-body text-black">
        <!--Title-->
        <h4 class="card-title ">Position: <?=$data['job_title'];?> Job ID: <?=$data['job_id'];?></h4>
        <hr>             
        <p> <i class="fa fa-map-marker"></i>Education: <?=$data['job_qualification'];?> </p>
        <p><i class="fa fa-bed"></i>Deadline: <?=$data['job_deadline'];?></p>
        <!-- Card footer -->
                    </div>
                </figcaption>
                    </a>
                    </div>                
            </figure> 
            <?php };?>
            </div>
        </div>
    </div>
 <div id="load-more">
 <p class="text-center"> 
 <a href="#" class="btn btn-lg danger">LOAD MORE</a>
</div>
</p>
</div>

</section>
<!-- gallery  end -->

 <?php
 get_part('about.php');
 get_part('footer.php');
 ?>
