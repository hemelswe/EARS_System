 <!-- slider start -->
    <!--Carousel Wrapper-->
<section id="slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="img/pexels-photo.jpg" alt="First slide">
            <div class="carousel-caption d-none d-md-block">
            <!--   <h3>Good Service IS our Passion</h3>
              <h1 class="d-inline-block ">Awesome apartment </h1>
              <p>No matter what the weather, no matter what the situation we are in, if we have the right perspective in life, life will always be beautiful!! </p> -->
<a href="special_offer.html" class="btn btn-danger">SPECIAL OFFER</a>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="img/pexels-photo-257897.jpeg" alt="Second slide">
            <div class="carousel-caption d-none d-md-block">
              <h3>Good Service IS our Passion</h3>
            <!--   <h1 class="d-inline-block">Awesome apartment </h1>
              <p>No matter what the weather, no matter what the situation we are in, if we have the right perspective in life, life will always be beautiful!!</p> -->
<a href="special_offer.html" class="btn btn-danger">SPECIAL OFFER</a>
            </div>
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="img/apartment-single-2.jpg" alt="Third slide">
            <div class="carousel-caption d-none d-md-block">
              <!-- <h3>Good Service IS our Passion</h3>
              <h1 class="d-inline-block">Awesome apartment </h1>
              <p>No matter what the weather, no matter what the situation we are in, if we have the right perspective in life, life will always be beautiful!!</p> -->
<a href="special_offer.html" class="btn btn-danger">SPECIAL OFFER</a>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
</section>
<!--/.Carousel Wrapper-->
<!-- slider end -->