<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Material Design Bootstrap</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">


    <!-- Start your project here-->
   
   <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
</head>


<body>
                      
<!-- Navbar START-->
<section class="top-head ">
<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
                      <li class="nav-item active">

                            <a class="nav-link  text-white" href="index.php"> <i class="fa fa-home"></i> <b>HOME</b> <span class="sr-only">(current)</span></a>
                      </li>
                     
                  
                    <li class="nav-item dropdown">
                            <a class="nav-link   text-white dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-paperclip"></i></i> <b>Job</b></a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="#"><b> Job Details </b></a>
                            <a class="dropdown-item" href="#"><b> Job Listing</b></a>
                           
                        </div>
                    </li>
                      
                      <li class="nav-item dropdown">
                            <a class="nav-link   text-white dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-paperclip"></i></i> <b>Candidate</b></a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="#"><b> Candidate List </b></a>
                            <a class="dropdown-item" href="#"><b> Candidate Profile </b></a>
                           
                        </div>
                         </li>
                      <li class="nav-item dropdown">
                            <a class="nav-link   text-white dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-book fa-fw"></i></i> <b>Employ</b></a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="#"><b> Employ List</b></a>
                            <a class="dropdown-item" href="#"><b> Employ Details</b></a>
                           
                        </div>
                      </li>
                       
                      <li class="nav-item">
                            <a class="nav-link   text-white" href="#"><i class="fa fa-th-large"></i>  <b>Contact US </b></a>
                      </li>
                      <li class="nav-item">
                            <a class="nav-link   text-white" href="login.php"><i class="fa fa-sign-in"></i>  <b>Sign In </b></a>
                      </li>
                      <li class="nav-item">
                            <a class="nav-link   text-white" href="registration.php"><i class="fa fa-user-plus"></i>  <b>Sign Up </b></a>
                      </li>
    </ul>
 </div>         
</nav>
</section>
<!-- NAVBER END -->