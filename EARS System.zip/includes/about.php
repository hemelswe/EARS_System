<!-- ABOUT START -->                                                                 
<section class="about">
<div class="container">
                <div class="text-center">
             <h2><b>About Us</b></h2>
             <h4 >WELCOME TO OUR  COMPANY</h4>
           </div>
    <div class="row">
        <div class="col-md-12">
        <div id="accordion" role="tablist">
  <div class="card">
    <div class="card-header" role="tab" id="headingOne">
      <h5 class="mb-0">
        <a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          OUR COMPANY
        </a>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
       serves the full lifecycle of owning and living in a home: buying, selling, renting, financing, remodeling and more. It starts with Zillow's living database of more than 110 million U.S. homes - including homes for sale, homes for rent and homes not currently on the market, as well as Zestimate home values, Rent Zestimates and other home-related information. Zillow operates the most popular suite of mobile real estate apps. 
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" role="tab" id="headingTwo">
      <h5 class="mb-0">
        <a class="collapsed" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          OUR TRIM & CONDITION
        </a>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
       <P>1.Agreement to rent. agrees to rent the house located at  to for the term of this House Rental Lease Agreement.</P>
       <P>2.Term of lease.  The rental term will start on [START DATE] and end on [END DATE].</P>
       <P>3.Rent.  Renter agrees to pay [TOTAL RENT] in exchange for use of the House under the conditions of this House Rental Lease Agreement.</P>
      
      
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" role="tab" id="headingThree">
      <h5 class="mb-0">
        <a class="collapsed" data-toggle="collapse" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
         OUR COUSTOMER
        </a>
      </h5>
    </div>
   
    </div>
  </div>
</div>

        </div> <!-- /col-md-4 -->

    </section>
<!-- ABOUT END -->