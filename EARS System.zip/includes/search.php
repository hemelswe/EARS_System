
<!-- Search Start -->                                  
<section class="Availability">
    <h2 class="text-center">Search your <b>Job</b></h2>
                                     
 <div class="contact-section text-center">
      <div class="container">
      
          
              <form class="form-inline">

    <div class="md-form form-group">
        
        <input type="email" id="form91" class="form-control validate">
        <label for="form91" data-error="wrong" data-success="right">Job Name</label>
    </div>

    <div class="md-form form-group">
       
        <input type="password" id="form92" class="form-control validate">
        <label for="form92" data-error="wrong" data-success="right">Prosition</label>
    </div>

    
    <div class="md-form form-group">
      
        <input type="password" id="form92" class="form-control validate">
        <label for="form92" data-error="wrong" data-success="right">Salary</label>
    </div>
</form>       
      </div>
      </div>
      <div class="text-center">
       <a href="404page.html" class="btn btn-lg danger" > CHECK AVAILABILITY</a>
                                   </div>
                                  
                                 </section>
<!-- Serach End -->