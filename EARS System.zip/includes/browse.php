 <!-- Browse Job start -->
                                  <section >
                                    <div class="container">
                                    <div class="text-center mt-5">
                                    <h2 class="text-center"> Browse Job</h2>
                                    <div class="popular">
                                    <a href="all_apartment.html" class="btn btn-lg danger"><b>Web Developer</b><span class="sr-only">(current)</span></a>
                                <a href="apartment.html" class="btn btn-lg danger"><b>Android Apps Developer</b></a>
                                                  <a href="#" class="btn btn-lg danger"><b>Java</b></a>
                                               <a href="#" class="btn btn-lg danger"><b>Data Science</b></a>
                                        <a href="#" class="btn btn-lg danger"><b>Networking</b></a>
                             
                                 </div>
                                      
                                    </div>
                                      
                                    </div>
                                  </section>
<!-- Browser job end -->